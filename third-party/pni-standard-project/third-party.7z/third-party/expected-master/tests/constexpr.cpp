#include <catch2/catch.hpp>
#include <tl/expected.hpp>

TEST_CASE("Constexpr", "[constexpr]") {
    //TODO
}
