#ifndef SUBTEST_HPP_
#define SUBTEST_HPP_

void subtest_from_another_tranlation_unit();

#endif // SUBTEST_HPP_
